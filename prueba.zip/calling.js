var async=require('async');
var config=require("./config.json");
var request=require('request');
var msisdn=require('./msisdn.json');
var arrayMsisdn=[msisdn[0],msisdn[1],msisdn[2]];

async.each(arrayMsisdn,function(item,next)
{
async.waterfall([
    callLegacy.bind(null,{msisdn:item}),
    callBSS,
    function(result,err)
    {
        
        (function()
        {
        console.log("\nFINALIZADO WATERFALL"+result) ;
         next();
        })();
    }
]);
}
,function (err,result2)
{
    console.log("Fin de la iteracion async series");
}
);
function callLegacy(opt,callback)
{
    request({url:'https://'+config['host']+config['path']+'/'+opt["msisdn"]+'/account',
             headers:{'Authorization':'Bearer '+config['token'],
                      'User-Agent':'testing/edge'}},
            function(error,response,body)
            {
          //      console.log(error);
                 callback(null,opt.msisdn,body);
            });
}
function callBSS(msisdn,arg1,callback)
{
    request({url:'https://'+config['hostQA']+config['pathAccount']+'/'+msisdn+'/account'},
             function(error,response,body)
            {
                 //     console.log(error);
                 console.log(body);
                 if (error) return callback(error);
                 else
                     callback(null,'terminado la comparacion para '+msisdn+"\res"+arg1);

             });
}



